package Reusable;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReusableMethods {
    private static String Userinput;

    public static int timeout = 50;
    //method below is reusable methods
    public static void click(WebDriver driver, String locator) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator))).click();
        } catch (Exception e) {
            System.out.println("unable to click on element" + e);
        }
    }//end of click method

    //for sendkeys
    public static void sendKeys(WebDriver driver, String locator, String value) {
        WebDriverWait wait = new WebDriverWait(driver, 20);

        try {

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator))).sendKeys(value);

        } catch (Exception e) {
            System.out.println("unable to send keys" + e);
        }
    }  //end of sendkeys

    public static WebDriver chromeDriver() {
        //connecting to chrome driver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Fablia\\IdeaProjects\\First_Poject\\src\\UTILITIES\\chromedriver.exe");
        ChromeOptions Options = new ChromeOptions();
        Options.addArguments("start-maximized", "incognito","disable-extension");
        WebDriver driver = new ChromeDriver(Options);
        return driver;
    }

    //method for gettext
    public static String getcontent(WebDriver driver, String locator) {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        String message = null;
        try {
            message = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator))).getText();
        } catch (Exception e) {
            System.out.println("unable to capture the value + e");
        }
        return message;

    }

    //click on element using mouse movement
    //setting webdriver & locator
    public static void clickByMouse(WebDriver driver, String locator) {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        Actions mouseHover = new Actions(driver);
        try {
            WebElement hoverElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
            mouseHover.moveToElement(hoverElement).click().build().perform();
            //wait statement till element presents & hovering mouse to click on the elements & asking to perform the action
        } catch (Exception e) {
            System.out.println("unable to click on element by mouse movement..." + e);

        }
    }

    //hover using mouse
    public static void mouseHover(WebDriver driver, String locator) {
        //explicit wait allow to reach in specific element.instead of thread.sleep
        WebDriverWait wait = new WebDriverWait(driver, 20);
        Actions mouseMovement = new Actions(driver);
        try {
            WebElement Element= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
            mouseMovement.moveToElement(Element).build().perform();
            //we are loacting element by xpath and waiting to catch the element
            //
        } catch (Exception e) {
            System.out.println("unable to hover an element" + e);
        }
    }

    public static void scrollIntoElement(WebDriver driver, String locator) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        WebDriverWait wait = new WebDriverWait(driver, 30);
        try {
            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
            jse.executeScript("arguments[0].scrollIntoView", element);
        } catch (Exception e) {
            System.out.println("Unable to scroll into view using executor " + e);
        }


    }

}
