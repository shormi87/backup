package Ecommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

public class Express {

        WebDriver driver;
        SoftAssert softAssert;


        @BeforeSuite
        //open methods for each test we r executing
        public void openbrowser() throws InterruptedException {
            driver = Reusable.ReusableMethods.chromeDriver();
        }

            @Test(priority = 1)

            public void testscenario () throws InterruptedException {
                //open chrome driver
                WebDriver driver = Reusable.ReusableMethods.chromeDriver();
                //navigate to EXPRESS.COM
                driver.navigate().to("https:www.express.com");
                // wait few secons
                Thread.sleep(2500);


                //hovering over womens tab
                Reusable.ReusableMethods.mouseHover(driver, "//*[@class='nav-target']");

                //hover over on accessories.
                Reusable.ReusableMethods.mouseHover(driver, "//*[@class='subnav-target']");
                /*Reusable.ReusableMethods.mouseHover(driver,"//*[@contains(@aria-label,'watches & jwellery')]");
               // Reusable.ReusableMethods.clickByMouse(driver,"//*[@contains(@aria-label,'watches & jwellery')]");
                Reusable.ReusableMethods.mouseHover(driver,"//*[@class='subsubnav-target')]");
                Reusable.ReusableMethods.clickByMouse(driver,"//*[@class='subsubnav-target')]");*/
                //selecting jwellery
                Reusable.ReusableMethods.mouseHover(driver, "//*[contains(@aria-label='jewelry')]");
                Reusable.ReusableMethods.click(driver, "//*[contains(@aria-label='jewelry')]");
                //selecting earrings
                Reusable.ReusableMethods.clickByMouse(driver, "//*[text()='Earrings']");
                Thread.sleep(3000);
                //by following syntax asserting that we r in the right page
                softAssert.assertEquals("Jewelry For Women", driver.getTitle(), "should display title");
                softAssert.assertTrue(driver.findElement(By.xpath("//*[text()='Earrings']")).isDisplayed(), "earrings should appear");
                //hover over to the first iteam
                Reusable.ReusableMethods.mouseHover(driver, "//*[@class='active loaded']");
                //click on express view
                Reusable.ReusableMethods.click(driver, "//*[@class='express-view']");
                //clicking on a color
                //ekhane.get()add hobe findelement method use korbo
                Reusable.ReusableMethods.clickByMouse(driver, "//*[text()='SHINY GOLD']");
                //adding iteam to the bag
                Reusable.ReusableMethods.click(driver, "//*[@class='btn btn-cta btn-add-to-bag btn-black]'");
                //hover overing to bag icon
                Reusable.ReusableMethods.mouseHover(driver, "//*[@class='bag-icon']");
                //assert that i am in my shopping bag page
                softAssert.assertEquals("Express", driver.getTitle(), "should display title");
                softAssert.assertEquals(driver.findElement(By.xpath("//*[@class='_3OxzC']")).isDisplayed(), "shopping bag should display");
                //select dropdown
                Thread.sleep(4000);
                Reusable.ReusableMethods.click(driver, "//*[@role='listbox']");
                //selecting quantity
                Reusable.ReusableMethods.clickByMouse(driver, "//*[contains(@aria-label='Quantity 2']");
                //checkout
                Reusable.ReusableMethods.clickByMouse(driver, "//*[@aria-label='Continue to Checkout']");
            }//end of test 1


        @Test(priority=2)
                public void testscean() throws InterruptedException {
            Thread.sleep(2500);

                //checkout as a guest
                Reusable.ReusableMethods.mouseHover(driver, "//*[text()='Continue as Guest']");
                Reusable.ReusableMethods.click(driver, "//*[text()='Continue as Guest']");
                Thread.sleep(3000);
                //entering information
                Reusable.ReusableMethods.sendKeys(driver, "//*[@aria-label='First Name']", "abc");
                Reusable.ReusableMethods.sendKeys(driver, "//*[@aria-label='Last Name']", "x");
                Reusable.ReusableMethods.sendKeys(driver, "//*[@name='email']", "sharmin_37@hotmail.com");
                Reusable.ReusableMethods.sendKeys(driver, "//*[@name='confirmEmail']", "sharmin_37@hotmail.com");
                Reusable.ReusableMethods.sendKeys(driver, "//*[@name='phone']", "3474252260");
                Reusable.ReusableMethods.click(driver, "//*[@class='Continue']");
                Thread.sleep(5000);
                //filling out shipping and billing address

                Reusable.ReusableMethods.sendKeys(driver, "//*[@name='phone']", "3474252260");

                Reusable.ReusableMethods.sendKeys(driver, "//*[@id='shipping-firstName']", "abc");
                Reusable.ReusableMethods.sendKeys(driver, "//*[@name='shipping.lastName']", "x");

                Reusable.ReusableMethods.click(driver, "//*[@name='shipping.countryCode']");
                Reusable.ReusableMethods.click(driver, "//*[@name='shipping.countryCode']");
                Reusable.ReusableMethods.sendKeys(driver, "//*[text()='Street Address']", "77-07");
                Reusable.ReusableMethods.sendKeys(driver, "//*[@aria-label='Apt #, Floor, etc. (optional)']", "02");
                Reusable.ReusableMethods.sendKeys(driver, "//*[@name='shipping.postalCode']", "11417");
                Reusable.ReusableMethods.sendKeys(driver, "//*[@name='shipping.city']", "ozone park");
                //
                Reusable.ReusableMethods.click(driver, "//*[@name='shipping.state']");
                JavascriptExecutor jse = (JavascriptExecutor) driver;
                jse.executeScript("scroll(0,10000)");
                Reusable.ReusableMethods.click(driver, "//*[@value='NY']");


                /*WebElement StateList = driver.findElement(By.name("shipping.state"));
                Select dropDown = new Select(StateList);
                dropDown.selectByVisibleText("New York");*/
                //checking the box billing adress same as shippping
                Boolean elementState = driver.findElement(By.xpath("//*[contains(@type,'checkbox')]")).isSelected();
                System.out.println("checked billing address as same as shipping address");
                //click on continue button
                Reusable.ReusableMethods.click(driver, "//*[@class='Continue']");
                //capturing and printing result
                String searches = Reusable.ReusableMethods.getcontent(driver, "//*[@class='_1oFkX']");

                System.out.println("my contact informtion " + searches);
                Thread.sleep(6000);
            }

                @AfterSuite
                public void closeBrowser () {
                    driver.close();


                }
            }


