package day9_testng;

import Reusable.ReusableMethods;
import org.apache.http.util.Asserts;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


public class goodle_testng {

    WebDriver driver;
    SoftAssert softAssert;


    @BeforeMethod
    public void openbrowser(){
        driver = Reusable.ReusableMethods.chromeDriver();

    }
    @Test(priority = 1)
    public void testscenarion(){
        softAssert = new SoftAssert();
        //navigate to google
        driver.navigate().to("https://www.google.com");
        //verify i'm on the right page by using assertion assertEquals()
        softAssert.assertEquals("Gooooogle",driver.getTitle(),"should display title");
        //let's verify if the google image is displayed or not using assertTrue();
        softAssert.assertTrue(driver.findElement(By.xpath("//*[@id='hplogo']")).isDisplayed(),"Logo Should Appear");
        //entering name on search field
        driver.findElement(By.name("q")).sendKeys("cars");
        //click on somewhere outside of the page to minimized the search dropdown
        Reusable.ReusableMethods.click(driver,"//*[@id='lga']");
        //click on google search
    }



   @AfterMethod
   public void closebrowser() {
        driver.quit();

        softAssert.assertAll();

   }

}//end
