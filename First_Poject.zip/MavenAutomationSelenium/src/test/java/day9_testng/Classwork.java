package day9_testng;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;

/*public class Classwork {

    WebDriver driver;
    SoftAssert softAssert;


    @BeforeMethod
    public void openbrowser() {
        driver = Reusable.ReusableMethods.chromeDriver();

    }

    @Test(priority = 1)
    public void testscenario() throws InterruptedException {
        //open chrome driver
        WebDriver driver = Reusable.ReusableMethods.chromeDriver();
        //navigate to .com
        driver.navigate().to("https:www.yahoo.com");
        // wait few secons
        Thread.sleep(2000);
        //get all navigation iteam

        List<WebElement> tabscount = driver.findElements(By.xpath("//*[@role='navigation']"));
        System.out.println("tab count is" + tabscount.size());


//ENTERING INTO THE LOOP
        for (int i = 0; i < tabscount.size(); i++) {

            String getName = driver.findElements(By.xpath("//*[contains(@class,'Msatrt(px')]")).get(i).getText();
           // String getName = driver.findElements(By.xpath("//*[contains,(@role,'navigation')]")).get(i).getText();
            //String getName = driver.findElements(By.xpath("//*[@class='menuitem']"));
            System.out.println("my tab is" + getName);
            //navigate to nutrition on searc
            //syntax reuable.reusablemethod is package name.classname.mehtodname


        }
//navigate to nutrition on searc

       // driver.findElements(By.xpath("//*[@id='uh-search-box']")).("nutrition");

//Reusable.ReusableMethods.click(driver,"//*[@id='uh-search-box']";
//reusable method for click
      //  Reusbale.ReusableMethods.click(driver,"//*[@id='uh-search-button']";

        Thread.sleep(4000);
//defining javascrip executor command to scroll
        JavascriptExecutor jse= (JavascriptExecutor)driver;
//scrolloing down 100
        jse.executeScript("scroll(0,10000)");
//doojg split on the message
        String msg = Reusable.ReusableMethods.getcontent(driver,"//[contains(@class,'reg searchBottom')]");

        String[] Arraymessage= msg.split("Next");
        System.out.println(Arraymessage[1]);
        Thread.sleep(4000);
//click on sign in button

//scrolloing down 100
        jse.executeScript("scroll(0,-10000)");
        Reusable.ReusableMethods.click(driver,"//*[@id='uh-signin']");
        Boolean elementState = driver.findElement(By.xpath("//*[contains(@for,'persistent')]")).isSelected();
        System.out.println("cheked the stay sigin box");
        Reusable.ReusableMethods.sendKeys(driver,"//*[@id='login-username']",);
        Reusable.ReusableMethods.click(driver,"//*[@id='login-signin']");
Thread.sleep(2000);
        String getName = driver.findElement(By.xpath("//*[contains(@class,'Msatrt(px')]")).getText();
        String error ="Sorry, we don't recognize this email";
        Assert.assertEquals(error,error);
    }
    @AfterMethod
    public void closeBrowser(){
        driver.close();














    }
    }*/

