package day9_testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.util.List;

public class sundayclass {

     @Test
      public void testScenario() throws InterruptedException {
         //open chrome driver
            WebDriver driver = Reusable.ReusableMethods.chromeDriver();
            //navigate to usps .com
            driver.navigate().to("https:www.usps.com");
           // wait few secons
            Thread.sleep(2000);
            //get all navigation iteam

            List<WebElement> tabscount = driver.findElements(By.xpath("//*[@class='menuitem']"));
            System.out.println("tab count is"+ tabscount.size());


//ENTERING INTO THE LOOP
         for (int i = 0;i<tabscount.size();i++){

             String getName= driver.findElements(By.xpath("//*[@class='menuitem']")).get(i).getText();
             //String getName = driver.findElements(By.xpath("//*[@class='menuitem']"));
             System.out.println("my tab is" + getName);


        }




    }
}

