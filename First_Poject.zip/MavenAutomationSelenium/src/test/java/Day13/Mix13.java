package Day13;

import com.beust.jcommander.Parameter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import jdk.internal.org.objectweb.asm.commons.Method;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import java.util.UUID;

public class Mix13 {
    WebDriver driver;
    SoftAssert softAssert;
    ExtentReports reports;
    ExtentTest logger;

        @Parameters("browser")
        @BeforeSuite
        public void openbrowser(String Browser){
            if(Browser.equalsIgnoreCase("firefox")){
                reports= new ExtentReports("C:\\Users\\Fablia\\Desktop\\java class\\Extentreport" + UUID.randomUUID() + ".html", true);
            }
                System.setProperty("webdriver.gecko.driver","src\\main\\resources\\geckodriver.exe");
                driver = new FirefoxDriver();
                driver.manage().window().maximize();

            }else if (browser.equalsIgnoreCase("chrome")){
            reports = new ExtentReports("C:\\Users\\Fablia\\Desktop\\java class\\Extentreport" + UUID.randomUUID() + ".html", true);
            System.setProperty("webdriver.chrome.driver","src\\main\\resources\\chromedriver.exe");
            ChromeOptions options = new ChromeOptions();
            options.addArguments("incognito","start maximized");
            driver = new ChromeDriver(options);

            }

//beforemthod is only defined to capture your test method name to imported on your html report
    @BeforeMethod
    public void MethodName(){
            logger = reports.startTest(Method.getName);

    }
        @Test
        public void testscenario() throws InterruptedException {
            driver.navigate().to("www.google.com");
            Thread.sleep(2500);
        }
        @AfterMethod
        public void closeBrowser(){
            //driver.quit();
        }




    }
