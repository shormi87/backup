package day10;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;

public class ReusableMethods_reports {
    private static String Userinput;

    public static int timeout = 50;
    //method below is reusable methods
    public static void click(WebDriver driver, String locator) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator))).click();
        } catch (Exception e) {
            System.out.println("unable to click on element" + e);
        }
    }//end of click method

    //for sendkeys(Entersomething)
    public static void sendKeys(WebDriver driver, String locator, String value,ExtentTest logger,String elementName) throws IOException {
        WebDriverWait wait = new WebDriverWait(driver, 20);

        try {
            logger.log(LogStatus.INFO,"ENTER A VALUE" +value+ "on element" + elementName);

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator))).sendKeys(value);

        } catch (Exception e) {
            logger.log(LogStatus.FAIL,"unable " + elementName);
            System.out.println("unable to send keys" + e);
            getScreenshots(driver,logger);
        }
    }  //end of sendkeys

    public static WebDriver chromeDriver() {
        //connecting to chrome driver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Fablia\\IdeaProjects\\First_Poject\\src\\UTILITIES\\chromedriver.exe");
        ChromeOptions Options = new ChromeOptions();
        Options.addArguments("start-maximized", "incognito","disable-extension");
        WebDriver driver = new ChromeDriver(Options);
        return driver;
    }

    //method for gettext
    public static String getcontent(WebDriver driver, String locator,ExtentTest logger,String elementName) {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        String message = null;
        try {
            logger.log(LogStatus.INFO, "CAPTURING TEXT FROM ELEMENT" + elementName);
            message = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator))).getText();
        } catch (Exception e) {
            System.out.println("unable to capture the value + e");
            logger.log(LogStatus.FAIL,"unable to get text from element" + elementName);
        }
        return message;

    }

    //click on element using mouse movement
    //setting webdriver & locator
    public static void clickByMouse(WebDriver driver, String locator, ExtentReports report, ExtentTest logger,String elemmentName) throws IOException {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        Actions mouseHover = new Actions(driver);
        try {
            logger.log(LogStatus.INFO, "clicking on a element" + elemmentName);
             wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
           // mouseHover.moveToElement(hoverElement).click().build().perform();
            //wait statement till element presents & hovering mouse to click on the elements & asking to perform the action
        } catch (Exception e) {
            logger.log(LogStatus.FAIL,"UNABLE TO ");
            System.out.println("unable to click on element by mouse movement..." + e);
            getScreenshots(driver,logger);

        }
    }

    //hover using mouse
    public static void mouseHover(WebDriver driver, String locator) {
        //explicit wait allow to reach in specific element.instead of thread.sleep
        WebDriverWait wait = new WebDriverWait(driver, 20);
        Actions mouseMovement = new Actions(driver);
        try {
            WebElement Element= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
            mouseMovement.moveToElement(Element).build().perform();
            //we are loacting element by xpath and waiting to catch the element
            //
        } catch (Exception e) {
            System.out.println("unable to hover an element" + e);
        }
    }

    public static void scrollIntoElement(WebDriver driver, String locator) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        WebDriverWait wait = new WebDriverWait(driver, 30);
        try {
            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
            jse.executeScript("arguments[0].scrollIntoView", element);
        } catch (Exception e) {
            System.out.println("Unable to scroll into view using executor " + e);
        }


    }
  public static void getScreenshots(WebDriver driver,ExtentTest logger)throws IOException {
      String ImagePath = "C:\\Users\\Fablia\\Desktop\\Maven doc\\screenshots.png";
      //line below allows you to take screenshot(don't need to memorize the command)
      File sourceFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//Now you can do whatever you need to do with, for example copy somewhere
      FileUtils.copyFile(sourceFile, new File(ImagePath));
      String image = logger.addScreenCapture(ImagePath);
      logger.log(LogStatus.FAIL, "Verify Google Title", image);
  }


}
