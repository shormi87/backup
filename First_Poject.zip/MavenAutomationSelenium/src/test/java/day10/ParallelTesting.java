package day10;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

public class ParallelTesting {
   WebDriver driver;
   @Parameters("Browser")
    @BeforeMethod
    public void openbrowser(String Browser){
       if(Browser.equalsIgnoreCase("firefox")){
           System.setProperty("webdriver.gecko.driver","src\\main\\resources\\geckodriver.exe");
                   driver = new FirefoxDriver();
           driver.manage().window().maximize();

       }else if (Browser.equalsIgnoreCase("chrome")){

           System.setProperty("webdriver.chrome.driver","src\\main\\resources\\chromedriver.exe");
                   ChromeOptions options = new ChromeOptions();
            options.addArguments("incognito","start maximized");
            driver = new ChromeDriver();
       }
    }

@Test
    public void testscenario() throws InterruptedException {
    driver.navigate().to("www.google.com");
    Thread.sleep(2500);
}
       @AfterMethod
               public void closeBrowser(){
           //driver.quit();
    }





}
