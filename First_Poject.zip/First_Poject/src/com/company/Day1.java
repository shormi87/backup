package com.company;

public class Day1 {
    //method breaking down the class-actions of object e.g wheels,body etc
    //object e.g car
    //constructor is basically every class
    //a class can have more than one constructor
    //each class has to be at least one constructor
    //method is nothing but an action/sub-class(collection of objects)
    //under public class we create a subclass
    //two types of method void n return.return use by string/int.void only will perfom some actions
    //class is a blueprint
    //public class methods{
    //concatenation is print a massage with variable

       // public static myclass(){
       //     return something
       // }//with return
    //}public void abc() {


    //public static void main is a built in command
    //use to execute any method
    //string args dei cause the method(public static main) i can use to pass any arguments.string dile number or alphabet both use kora jai
    public static void main(String[]args){
        String name = "my name is john";
        int number =2;

       // System.out.println(name);
        System.out.println(name + " " + number);
        //concadination means adding space between two results


    }

}
