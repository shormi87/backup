package day3;

public class mainClass {

    public static void  main(String[] args){
       // Methods.addition(20,30);
        //eta int variable te anle i can use it as reuseable again
        int c = Methods.addition(90,30);

        int d = 10 + c;
        System.out.println("print" + d );


        Methods.substraction(90,30);

        //overloading
        // Methods.addition(20,30);
        //eta int variable te anle i can use it as reuseable again
         Methods.addition(90,30,40);








    }

}
