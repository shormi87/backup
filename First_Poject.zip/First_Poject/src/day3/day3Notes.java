package day3;

public class day3Notes {
    public static void main(String[] args) {
//create int variable call grades
//conditions are numbers 100-90 pele A,B.....
       /* int grade = 100;
        if (grade > 90 && grade <= 100) {
            System.out.println("Grade is A");
        } else if (grade > 80 && grade <= 90) {
            System.out.println("Grade is B");
        }*/

/* method : is a collection of statments grouped together to perform an operation.
syntax:public static int methodname(int a,int b){

}
int=numeric/return type;public static = modifier;methoNname= name of the me;a,b=formal perimiter;
if a method is not set to static then it cant be shared with another class.the processing of sharing called parametres
inheritence
if a method is not set as static then it cant be shared.if shares call as inheritance
custom method cant be executed by itself until its claeed indie a java main()method
void method dosent return anything but perform the operationwhen it is called by java main method
example of void method:
Public static void add(int a,int b){
System.out.println("my ..." + (a+b));
}
public static int add(int a,int b );
int c = a+b;
System.out.println("my   " + c);
return c;
}

//method overloading & overriding
overloading means 2 or more arguments in 1 class under the same method name but parametres {} are different
//allows to reuse the same method with additional peremetre
overriding means having two methods with the same method name & peremetres/value one of them in the parent class and another in child class.
overloading allows

 */





    }//end of main
}// end of class
