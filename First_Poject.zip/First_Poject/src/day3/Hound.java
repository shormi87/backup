package day3;

public class Hound  extends dog {
    //extends build command allows to extend diff class to this class

    public void bark(){
        System.out.println("howl");

    }
    public static void main(String[] args){
        dog abc = new Hound();
        abc.bark();
    }


}
