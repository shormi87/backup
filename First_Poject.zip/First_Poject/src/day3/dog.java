package day3;

public class dog {
     public void bark(){
         System.out.println("woof");
     }
}
