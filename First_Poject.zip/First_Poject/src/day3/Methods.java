package day3;

public class Methods {
    //return type

    public static int addition(int a, int b) {
        int c = a + b;
        System.out.println("my result is"+" " + c);
        return c;
    }

//void type
    public static void substraction( int a,int b){
        int c = a-b;
        System.out.println("My result is"+ " " + c);
    }

    //method overload

    public static int addition(int a, int b,int c) {
        int d = a + b +c;
        System.out.println("my result is"+" " + d);
        return d;
    }



}






