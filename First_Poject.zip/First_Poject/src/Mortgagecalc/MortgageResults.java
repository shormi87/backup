package Mortgagecalc;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.io.IOException;

public class MortgageResults {


    public static void main (String[] args) throws InterruptedException, WriteException, IOException, BiffException {
        //once we save the path excell we can open 4m intelij and add anything in the excell sheet
        //define a variable using Workbook to locate existing readable excel file
        Workbook readableFile = Workbook.getWorkbook(new File("src\\Resouseexcell\\excelldata\\Mortgage\\Book1.xls"));
        //locate readable sheet on my readable file
        Sheet readableSheet = readableFile.getSheet(0);
        //create a new work book which will mimic readableFile
        WritableWorkbook writableFile = Workbook.createWorkbook(new File("src\\Resouseexcell\\excelldata\\Mortgage\\Book1_Result.xls"), readableFile);
        //count the physical rows that are there in the readable sheet

        int rowNumber = readableSheet.getRows();
        //go thru
        System.out.println("Number of rows are " + (rowNumber -1));

        System.setProperty("webdriver.chrome.driver","C:\\Users\\Fablia\\IdeaProjects\\First_Poject\\src\\UTILITIES\\chromedriver.exe");
        ChromeOptions Options = new ChromeOptions();
        Options.addArguments("start-maximized","incognito");
        Thread.sleep(1000);

        WebDriver driver = new ChromeDriver(Options);


        for (int i = 1; i < rowNumber ; i++) {

            //get homeValue
            //get cell takes two arguments argument 1 is column and second argument is the row
            //columns starts from 0 not 1 in excel
            String Homevalue = readableSheet.getCell(0,i).getContents();

            //get  downpayment
            String Downpayment = readableSheet.getCell(1,i).getContents();
            //get loanamount
            String Loanamount = readableSheet.getCell(2,i).getContents();
            //get interest rate
            String Interestrate = readableSheet.getCell(3,i).getContents();
            //loanterm
            String Loanterm = readableSheet.getCell(4,i).getContents();
            //get start month
            String Startmonth = readableSheet.getCell(5,i).getContents();
            //get start year
            String Startyear = readableSheet.getCell(6,i).getContents();




            driver.get("https://www.mortgagecalculator.org/");
           // driver.manage().window().maximize();
            Thread.sleep(5000);
            //by making clear & sendkeys im entering something new values into the field


            driver.findElement(By.id("homeval")).clear();
            driver.findElement(By.id("homeval")).sendKeys(Homevalue);

            driver.findElement(By.id("downpayment")).clear();
            driver.findElement(By.id("downpayment")).sendKeys(Downpayment);

            driver.findElement(By.id("loanamt")).clear();
            driver.findElement(By.id("loanamt")).sendKeys(Loanamount);

            driver.findElement(By.name("param[term]")).clear();
            driver.findElement(By.name("param[term]")).sendKeys(Loanterm);


            driver.findElement(By.name("param[interest_rate]")).clear();
            driver.findElement(By.name("param[interest_rate]")).sendKeys(Interestrate);
            //or,
           // webelement homeval = driver.findelement by....
           // homeval.clear();
           // homeval.sendkeys(downpayment)

            driver.findElement(By.id("loanterm")).clear();
            driver.findElement(By.id("loanterm")).sendKeys(Loanterm);
            //dropdown on month so...evabe shob gula kora jabe

            WebElement Startmont = driver.findElement(By.xpath("//*[contains(@name,'start_month')]"));
            Select dropDown = new Select(Startmont);
            dropDown.selectByVisibleText(Startmonth);
            //command if theres no select comman present on inspect element then we do click.u can use the suntax for anything
            Startmont.click();
            driver.findElement(By.xpath("//*[text()='" + Startmonth + "']")).click();




            //start year


            driver.findElement(By.id("param[start_year]")).clear();
            driver.findElement(By.id("param[start_year]")).sendKeys(Startyear);


            driver.findElement(By.xpath("//*[@value='Calculate']")).click();

            Thread.sleep(2000);

//eta absolute xpath top er ta relative
            String Monthlypayment = driver.findElements(By.xpath("//*[@id=\"calc\"]/form/section/section[2]/div/div/div[1]/div/div/div[3]/div[2]/div[2]/div[1]/div[1]/h3")).get(0).getText();
            System.out.println("my monthly payment is " + Monthlypayment);
            //writableSheet command allows you to write something back to a excelsheeT
            WritableSheet wSheet = writableFile.getSheet(0);
            //create a Label/column using Label command to add the value to the cell of that sheet
            String[] array;
            Label label = new Label(7, i, Monthlypayment);
            //adding the label variable to cell
            wSheet.addCell(label);


        }//end of loop
        //writing to your writable file and close both writable and reading file end of the
        //loop
        writableFile.write();
        writableFile.close();
        readableFile.close();
        driver.quit();


    }//sub class ends here
}//end of main class
