package Day7;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.SendKeysAction;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class newclass {
   /* public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Fablia\\IdeaProjects\\First_Poject\\src\\UTILITIES\\chromedriver.exe");
        ChromeOptions Options = new ChromeOptions();
        Options.addArguments("start-maximized", "incognito");

        WebDriver driver = new ChromeDriver(Options);
        driver.navigate().to("httaps.mortgagecalculator.org");
        //enter homevalue but lets sawait for this element to be present
        // instead using thread.sleep
        WebDriverWait wait = new WebDriverWait(driver, 7);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=;homeval']"))).sendKeys(20000);
        //take steps from
        //only if theres a mistake that will handle otherwise it will play the script

        try {

            driver.findElement(By.id("loanamt")).sendKeys(Loanamount);

        } catch (Exception e) {
            System.out.println("element is not found" + e);
        }
//arekta way
        try {
            driver.findElement(By.id("loanamt")).isDisplayed() {
                driver.findElement(By.id("loanamt")).sendKeys(Loanamount);
            }else

            System.out.println("element is not found");
        //first e use korbo wait until syntax then whole page amra try n catch diye korte pari*/


    //implicit & explicit wait.implicit identical thread.sleep wait till perform the action
    //driver.manage().timeouts().implicitlyWait(4,timeunitsec);
    // explicit is wait untill perfom the action no matter how much time u set there.but if by the  time it cant find element it will faill
    // WebDriverWait wait = new WebDriverWait(driver,7);
    //  wait.until(ExpectedCondition.visibilityOfElementLocated(By.xpath("//[@id='']"))).click();
    // instead of using findlement we can do
    // ExpectedCondition.visibilityOfElementLocated(by)
    //try &catch for exception to give u reason why it exactly failed
    //scroll into the element/page/webpage
    // first define the scroll then put value
           /* JavascriptExecutor jse = (JavascriptExecutor)driver;
            jse.executeScript("scroll (0,20)");// going downwards
            jse.executeScript("scroll (0,-20)");//upwords
            jse.executeScript("scroll (20,0)");//going right
            jse.executeScript("scroll (-20,0)");//going right to left*/


           /* System.setProperty("webdriver.chrome.driver", "C:\\Users\\Fablia\\IdeaProjects\\First_Poject\\src\\UTILITIES\\chromedriver.exe");
            ChromeOptions Options = new ChromeOptions();
            Options.addArguments("start-maximized", "incognito");

            WebDriver driver = new ChromeDriver(Options);
            driver.navigate().to("https//:yahoo.com");
            Thread.sleep(2000);
            driver.findElement(By.name("")).sendKeys();
            driver.findElement(By.name("")).click();
            Thread.sleep(100);

            JavascriptExecutor jse = (JavascriptExecutor)driver;
            webelement element = driver.findElement()
            jse.executeScript("scroll (0,2000)");

            String message = driver.findElement(By.xpath());
            String[] arraymsg = message.split(" ");
            System.out.println("result is " + message);

           //implicit n thread.sleep u r harcoding the time
           //explicit time going to the element if fing that out movining to the next object
           //try n catch dosent have time exception so use explicitwait before script
           //put  wait untill syntax*/
}









