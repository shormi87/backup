package Dayno2;

public class HW_1 {

    public static void main(String[] args) {
        int score = 90;
        //INT JEI CONDITION SHETAR UPOR BASE KORE DIBO.FAIL CHAILE 50,A CHAILE 90 ETC.
        //OPERATOR >,<,==,>=,<=

        if (score > 90 && score <= 100) {
            System.out.println("Students will receive an A");
        } else if (score > 80 && score <= 90) {
            System.out.println("Students will receive an B");
        } else if (score >= 70 && score <= 80) {
            System.out.println("Students will receive an C");
        } else if (score >= 60 && score <= 70) {
            System.out.println("Students will receive an D");
        } else if (score > 50 && score <= 60) {
            System.out.println("Students will receive an F");
        }//end of condition
            //problem 2//print only bkln,manhattan
            String[] city;
            city = new String[4];

            city[0] = "Brooklyn";
            city[1] = "Queens";
            city[2] = "Manhattan";
            city[3] = "Bronx";
            city[4] = "Staten island";
            //for loop
            for (int i = 0; i <= city.length - 1; i++) {
                if (city[i] == "Brooklyn") {
                    System.out.println("my city is Brooklyn");
                } else if (city[i] == "Manhattan") {
                    System.out.println("my city name is Manhattan ");

                }//end of condition
            }// end of for loop
        //while loop
        int c = 0;
            while (c<city.length){

            }if (city[c]=="Brooklyn" || city[c]=="Manhattan") {

            System.out.println("city is " + city[c]);
        }
        c = c+1;

        }//end of MAIN

    }//END OF CLASS



