package saturday21.apr;

public class datadriventesting {

/*data driven excell download jar files.extract in a folder and add jxl in the modules library
    //save the xls to the 97.2003 format only.save in a file .save as hobe.
    //process step 1
   // import java io File
    // import jxl *.String
//Workbook readableFile = Workbook.getWorkbook(new File(""));
    //u get access with excelll by the syntax
    step 2 open readable workdbook
    Sheet.readableSheet = readableFile("sheet1");
    //line above retrive stored data in excell or
    Sheet readableSheet = readableFile.getSheet(0);
    step3 we create a duplicate file so that we can writeback to it
    command
     WritabelWorkbook writableFile = Workbook.createWorkbook(new File ("data-result.xls"));
     WEBELEMEENT COMMAND ALLOW U TO USE A TYPE OF VARIABLE TO STORE LOCATOR FROM A WEBPAGE FOR EXAMPLE I HV AN ELEMENET
     CALLED GENDER  DROPDON WHICH DEFINED BY ID=GENDER WHICH HAS TWO VALUE MALE N FEMALE NOW I CAN ELEMENETAE INTO WEBELEMENT LOCATOR
     WebElement myGender = driver.finelementbyxpath@id=gender
     now if u want to click on the element now i can just use myGender.click();
     now if i want to select an element fruit as appale i can use a built in Select command in selenium driver
     in oreder to use select we need to define the webElement as to whre it is located then once we locate the element by visibleText(),value
     and index.
     the tag name has to be in select tag
      syntax:
      WebElement fruitList = driver.findElement(By.id("fruits"));
      select dropDown = new new Select(fruitLIST);
      dropDown.selectByVisibleText("apple");
      wehn u select by value
      dropDown.selectByValue("apple");
      index hole array position theke index(1) hobe





*/
















}
