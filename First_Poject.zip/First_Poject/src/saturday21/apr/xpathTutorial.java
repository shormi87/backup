package saturday21.apr;

public class xpathTutorial {
    public static void main(String[] args) {


        //xapth holo id name class chara ja value dewa thake.allow you to use any property.
        //driver.findElement(By.xpath("//*[@value='']")).click();
        //text thakle @ use korbo na it will be //*[text()='abc']"
        //xpath contains--when constantly a value changes but main value reamin same we use xpath contains
        //a1,a2,a3 type change xpath contain e a ta constant thakbe.
        //xpath expression
        //example xpath

       // driver.findElement(By.name("q")).sendKeys(cars[i]);
        //same syntax xpath diye korle following
        //driver.findElement(By.xpath(//*[@name='q']")).sendKeys(cars[i]);
        //element inspect korle jodi only black letter/content show kore egula text
        //syntaxt for text.we will take only stable txt unique text
        //click on all
       // driver.findElement(By.xpath("//*[text()='all']")).sendKeys(cars[i]);
        //driver.findElement(By.xpath("//*[contains@id.'myAccount'])")).click
        //xpath contains syntax//basiclly u can put any word contains in this paremetres
       // driver.findElement(By.xpath("//*[contains(@id,'go')}")).sendKeys(cars[i]);
//element with same exact name n property--findlements
        //where all the element looks same i want to take one of them to perform the actions
       // driver.findElements(By.className("options")).get(0).click();
       // diffrenec:findelement locates an element by its property and value.where as findelements locates an array of elements where some elements
        //have same class & same properties and same values so we can identify specific elements of same group by index starts from 0.


    }//end of sub class



}//end of main class
