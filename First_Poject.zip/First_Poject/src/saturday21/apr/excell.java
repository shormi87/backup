package saturday21.apr;
/*import jxl.Workbook;
import jxl.write.WritableSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;
import java.io.IOException;*/


public class excell {
   /* public static void main (String[] args) throws IOException, jxl.read.biff.BiffException, InterruptedException {
        Workbook readableFile = Workbook.getWorkbook(new File("src\\Resouseexcell\\excelldata\\excelldata.xls"));

        jxl.Sheet readableSheet = readableFile.getSheet(0);

        jxl.write.WritableWorkbook writableFile = Workbook.createWorkbook(new File("src\\Resouseexcell\\excelldata\\excelldata_result.xls"), readableFile);
        int rownumber = readableSheet.getRows();
        System.out.println("Number of rows are " + (rownumber-1));
        //bing search result with directing to chrome driver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Sharmin\\Desktop\\selenium-2.53.0\\chromediver.exe");
        ChromeOptions Options = new ChromeOptions();
        Options.addArguments("start-maximized");

        WebDriver driver = new ChromeDriver(Options);
        //using for loop to call the cell data for excell rows
        int i = 0;
        for (int i =1,i<rownumber,i++){
            //store the countries into the variable
            String Country = readableSheet.getCell(0,i).getContents();
            //going to bing.com
            driver.navigate().to("https://www.bing.com");
            //entering the vriable citites into search field
            driver.findElement(By.xpath("//*[@name='q']")).sendKeys(Country[i]);
            driver.findElement(By.xpath("//*@class=sb_count]")).click();
            Thread.sleep(2000);


//right click on the result inspect and put the value
            String message = driver.findElement(By.id("resultStats")).getText();
            String[] arrayMessage = message.split(" ");
            WritableSheet
            i = i + 1;


        }


    }//main class*/



}
