package day8;

import Day7.ReusableMethods;
import org.openqa.selenium.WebDriver;

public class gOOGLEsearchusingREUSABLE {
    public static void main(String[] args){

       WebDriver driver = ReusableMethods.chromeDriver();
        driver.navigate().to("https://www.google.com");
       // driver.findElement(By.xpath("//*[@id='lst-ib']")).sendKeys("car"); or...
        ReusableMethods.sendKeys(driver,"//*[@id='lst-ib']","cars");
        ReusableMethods.click(driver,"//*[@id='lga']");
        ReusableMethods.click(driver,"//*[@name='btnK']");
        String searchResult = ReusableMethods.getcontent(driver,"//*[@id='resultStats']");
        String[] arraySearch = searchResult.split(" ") ;
        System.out.println("my search result is" + arraySearch[1]);









    }



}
