package day8;
/*mouse hovering n performing actions.clicking element,entering input,hovering over element
to define actions
Actions mouseAction = new Actions(driver);
hovering on element
WebElement element = driver.findElement(by.id....));
mouseAction.moveToElement(element).build().perform();
build perform when ending mouse action
        WebElement element = driver.findElement(by.id....));
mouseAction.moveToElement(element).click().build().perform()
 enter something on a field using mouse
        WebElement element = driver.findElement(by.id....));
mouseAction.moveToElement(element).sendKeys().build().perform()*/


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class topics8 {
    public static void main(String[]args){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Fablia\\IdeaProjects\\First_Poject\\src\\UTILITIES\\chromedriver.exe");
        ChromeOptions Options = new ChromeOptions();
        Options.addArguments("start-maximized", "incognito");

        WebDriver driver = new ChromeDriver(Options);
        //defining mouse action
        Actions mouseAction = new Actions(driver);
        //defining explicit wait
        WebDriverWait wait = new WebDriverWait(driver,10);
        //navigate to usps
        driver.navigate().to("https://www.usps.com");
       // navigate to usps,using explicit wait for quick tool tab to be present
        //once it is present we can store quick tool as webelement variable.
        //use mouse action to hover to the element
        //verify dropdown appear in link tools
        //wait till quick tool appera to the class
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='nav-first-element menuitem']")));
        //store bove elemnt in webelement locator to hover using mouse action
        WebElement quicktools = driver.findElement(By.xpath("//*[@class='nav-first-element menuitem']"));
//line below will hover over to that element using mouse movement
        mouseAction.moveToElement(quicktools).build().perform();
        //once the dropdown appears u can usse wait .until to click track package
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@alt='Tracking Icon']"))).click();
        //input some value on tracking field once u r on track a package page
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='tracking-input']"))).sendKeys("123");


















    }
}
