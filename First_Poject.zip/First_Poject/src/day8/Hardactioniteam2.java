package day8;

import Day7.ReusableMethods;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.WritableWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;

public class Hardactioniteam2 {
    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Fablia\\IdeaProjects\\First_Poject\\src\\UTILITIES\\chromedriver.exe");
        ChromeOptions Options = new ChromeOptions();
        Options.addArguments("start-maximized", "incognito");
        WebDriver driver = new ChromeDriver(Options);
        //defining mouse action
        Actions mouseAction = new Actions(driver);
        //defining explicit wait
        WebDriverWait wait = new WebDriverWait(driver,10);
        //navigate to usps
        driver.navigate().to("https://www.usps.com");
        //store above element in webelment locator to hover using mouse action
        ReusableMethods.mouseHover(driver,"//*[@role='menuitem']");
        ReusableMethods.scrollIntoElement(driver,"//*[@alt='Tracking Icon']");
        ReusableMethods.click(driver,"//*[@alt='Tracking Icon']");
       // ReusableMethods.scrollIntoElement(driver,"//*[@class='panel-word red-underline']");
      // ReusableMethods.mouseHover(driver,"//*[@class='panel-word red-underline']");

        //driver.findElement(By.xpath("//*[@id=\"headingOneAnchor\"]/span[3]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"headingOneAnchor\"]")).click();
        String locator = driver.findElements(By.xpath("//*[@class='tracking_reskin']")).get(0).getText();


//        driver.findElement(By.xpath("//*[@id=\"tracking-input\"]")).sendKeys("9400 1000 0000 0000 0000 00");
//        driver.findElement(By.xpath("//*[@id=\"trackPackage\"]/div[2]/button")).click();


    }
}
