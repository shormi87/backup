package day8;

import Day7.ReusableMethods;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
public class hardActionIteam {
    public static void main(String[] args) throws InterruptedException, WriteException, IOException, BiffException {
        //line below defining the method
        WebDriver driver = ReusableMethods.chromeDriver();

//once we save the path excell we can open 4m intelij and add anything in the excell sheet
                //define a variable using Workbook to locate existing readable excel file
                Workbook readableFile = Workbook.getWorkbook(new File("src\\Resouseexcell\\excelldata\\Mortgage\\weirdHw\\excelldata.xls"));
                //locate readable sheet on my readable file
                Sheet readableSheet = readableFile.getSheet(0);
                //create a new work book which will mimic readableFile
                WritableWorkbook writableFile = Workbook.createWorkbook(new File("src\\Resouseexcell\\excelldata\\Mortgage\\weirdHw\\excelldata_result.xls"), readableFile);
                //count the physical rows that are there in the readable sheet

                int rowNumber = readableSheet.getRows();

        //defining mouse action
        Actions mouseAction = new Actions(driver);
        //defining explicit wait
        WebDriverWait wait = new WebDriverWait(driver,10);
        //navigate to usps
        driver.navigate().to("https://www.usps.com");
        //store above element in webelment locator to hover using mouse action
        ReusableMethods.mouseHover(driver,"//*[@role='menuitem']");
       // ReusableMethods.scrollIntoElement(driver,"//*[@class='https://www.usps.com/assets/images/home/schedule_pickup.svg']");
        ReusableMethods.click(driver,"//*[@class='tool-pickup']");
        //once the dropdown appears u can usse wait .until to click track package
        // wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@alt='Tracking Icon']"))).click();
        //click on element using click method
      //  ReusableMethods.click(driver,"//*[@id=\"g-navigation\"]/div/nav/ul/li[1]/div/ul/li[5]/a']");
       //driver.findElement(By.xpath("//*[@id=\"g-navigation\"]/div/nav/ul/li[1]/div/ul/li[5]/a")).click();


        for (int i = 1; i < rowNumber; i++) {
            //we r staring from 1 becase row nu 0 is header

                    //get homeValue
                    //get cell takes two arguments argument 1 is column and second argument is the row
                    //columns starts from 0 not 1 in excel
                    String Firstname = readableSheet.getCell(0, i).getContents();

                    String Lastname = readableSheet.getCell(1, i).getContents();
                    String phonenumber = readableSheet.getCell(2, i).getContents();
                    String StreetAddress = readableSheet.getCell(3, i).getContents();
                    String emailaddress = readableSheet.getCell(4, i).getContents();
                    String city = readableSheet.getCell(5, i).getContents();
                    String States = readableSheet.getCell(6, i).getContents();
                    String zipcode = readableSheet.getCell(7, i).getContents();

//using navigate because its open only one window
                    driver.navigate().to("https://www.usps.com");
                    // driver.manage().window().maximize();

            ReusableMethods.mouseHover(driver,"//*[@role='menuitem']");
            // ReusableMethods.scrollIntoElement(driver,"//*[@class='https://www.usps.com/assets/images/home/schedule_pickup.svg']");
            ReusableMethods.click(driver,"//*[@class='tool-pickup']");


                    driver.findElement(By.name("tFName")).sendKeys(Firstname);

                    driver.findElement(By.name("tLName")).sendKeys(Lastname);

                    driver.findElement(By.name("tPhone")).sendKeys(phonenumber);

                    driver.findElement(By.name("tAddress")).sendKeys(StreetAddress);

                    driver.findElement(By.xpath("//*[@class='input-field']")).sendKeys(emailaddress);

                    driver.findElement(By.name("tCity")).sendKeys(city);
                    //dropdown on month so...evabe shob gula kora jabe
            ReusableMethods.click(driver,"//*[@class='select-current-text']");
            //directly inspect state element and set it down

            //String statelocator = use xpath loator directly
//ReusableMethods.click(driver,statelocator);


                    //command if theres no select comman present on inspect element then we do click.u can use the suntax for anything
                    driver.findElement(By.xpath("//*[@class='select-current-text']")).click();

                    driver.findElement(By.name("tZip")).sendKeys(zipcode);
                    Thread.sleep(2500);


                    driver.findElement(By.id("a-checkavailable")).click();
                   // i can use reusable instead
//
                    Thread.sleep(2000);

//eta absolute xpath top er ta relative
                  String searches=  ReusableMethods.getcontent(driver,"//*[]");
                  //expected result ta elent locate korbo
            System.out.println("my name & address is " + searches);

                    //writableSheet command allows you to write something back to a excelsheeT
                    WritableSheet wSheet = writableFile.getSheet(0);
                    //create a Label/column using Label command to add the value to the cell of that sheet
                    String[] array;
                    Label label = new Label(8, i, searches);

                    //adding the label variable to cell
                    wSheet.addCell(label);


                }//end of loop
                //writing to your writable file and close both writable and reading file end of the
                //loop
                writableFile.write();
                writableFile.close();
                readableFile.close();
                driver.quit();
            }
        }


