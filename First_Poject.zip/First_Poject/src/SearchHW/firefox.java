package SearchHW;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class firefox {
    public static void main(String[] args) throws InterruptedException {

        String[]Cars = new String[4];
        Cars[0] = "Toyota";
        Cars[1] = "Honda";
        Cars[2] = "Ford";
        Cars[3] = "Tesla";

        for (int i = 0; i<=Cars.length -1;i++) {

            WebDriver driver = new FirefoxDriver();
            driver.get("https://www.google.com/");
            driver.manage().window().maximize();
            Thread.sleep(5000);
            driver.findElement(By.name("q")).sendKeys("Toyota");
            Thread.sleep(2000);
            driver.findElement(By.id("resultStats")).click();
            Thread.sleep(2000);

            driver.findElement(By.id("q")).sendKeys("Honda");
            Thread.sleep(2000);
            driver.findElement(By.name("resultStats")).click();
            Thread.sleep(2000);

            driver.findElement(By.name("q")).sendKeys("Ford");
            Thread.sleep(2000);
            driver.findElement(By.id("resultStats")).click();
            Thread.sleep(2000);

            driver.findElement(By.name("q")).sendKeys("Tesla");
            Thread.sleep(2000);
            driver.findElement(By.id("resultStats")).click();
            Thread.sleep(2000);


            String searchResult = driver.findElement(By.id("resultStats")).getText();

            String[]arrayResult = searchResult.split(" ");
            System.out.println("my search result for Cars" + Cars[i] + "is" + arrayResult[1]);
            driver.quit();



        }

    }
}
