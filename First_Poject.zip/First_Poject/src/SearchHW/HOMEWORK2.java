package SearchHW;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HOMEWORK2 {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\Fablia\\IdeaProjects\\First_Poject\\src\\UTILITIES\\chromedriver.exe");

        ChromeOptions Options = new ChromeOptions();
        Options.addArguments("start-maximized","incognito");//private browsing mood
        WebDriver driver = new ChromeDriver();



        driver.get("https://www.bing.com");
        driver.manage().window().maximize();

/*
//defining driver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Sharmin\\Desktop\\selenium-2.53.0\\chromediver.exe");
        ChromeOptions Options = new ChromeOptions();
        Options.addArguments("start-maximized");

        WebDriver driver = new ChromeDriver(Options);
        //start adding values in array
        String[] cars = new String[4];
         cars[0] = "Ford";
        cars[1] = "Toyota";
        cars[2] = "Honda";
        cars[3] = "Audi";

        //creating a loop to iterate through the value
            for (int i = 0; i <= cars.length - 1; i++){
            System.out.println(cars[i]);


            // driver.get() or we can put//
            driver.navigate().to("https://www.google.com");
            Thread.sleep(2000);
            //to locate an element in selenium theres are few in built in comman u can locate element by name,id,class/
            //right click on search button to inspect the element
            driver.findElement(By.name("q")).sendKeys(cars[i]);
            //click on search button right click on the search
            driver.findElement(By.id("lga")).click();
            Thread.sleep(2000);


//right click on the result inspect and put the value
            String message = driver.findElement(By.id("resultStats")).getText();
            String[] arrayMessage = message.split(" ");
            System.out.println("My serch result number for " + cars[i] + " is " + arrayMessage[1]);

        }
        //always quit the driver end of the loop//
         driver.quit();*/




    }
}
